angular.module("myApp.search", []);
